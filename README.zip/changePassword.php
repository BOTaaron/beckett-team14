<!doctype html>
<html lang="en">

<head>
    <!--character width              -->
    <meta charset="utf-8">
    <!--page to fit screen at diff widths    -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-compatible" content="ie=edge">
    <!--  page title  -->
    <title>Password Reset</title>
    <!-- stylesheet reference   -->
    <link href="main.css" rel="Stylesheet" type="text/css" />
    <!-- icon -->
    <link rel="icon" href="images/Logop2.jpg" type="image/x-icon">
     <!-- social media icons -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">


</head>

<body>
    <div class="container">

                    </svg>
                </a>

   
        </div>
            <!--main page content-->
             <body>
                <body style="background-color: #962c3a;text-align:center">
                </body>
                <div class="container">
                <br>
                <br>
                <br>
                <br>
                <br>
                <h1>PASSWORD RESET</h1>
                <p>Please enter your new password</p>
             
                </div>
                
                
    <div class="container">
            <div class="form-group">
                <input type="password" class="form-control" id="email" name="New password" placeholder="New password*" tabindex="1" required>
                <br>
                <input type="password" class="form-control" id="email" name="Confirm password" placeholder="Confirm password*" tabindex="2" required>

                <div>
                    <br>
                <button type="submit" class="btn" onclick="location.href='changePasswordConfirmed.php'">CONFIRM</button>
                </div>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
            
      


                </div>

            </div>
        </div>
        <span class="pix">
         </span>


    
        </footer>

    </div>
</body>
</html>