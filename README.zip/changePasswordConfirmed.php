<?php




    header("Refresh:4;url=signIn.php");

?>



<!doctype html>
<html lang="en">

<head>
    <!--character width              -->
    <meta charset="utf-8">
    <!--page to fit screen at diff widths    -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-compatible" content="ie=edge">
    <!--  page title  -->
    <title>Password Reset</title>
    <!-- stylesheet reference   -->
    <link href="main.css" rel="Stylesheet" type="text/css" />
    <!-- icon -->
    <link rel="icon" href="images/Logop2.jpg" type="image/x-icon">
     <!-- social media icons -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">


</head>

<body>
    <div class="container">

                    </svg>
                </a>

   
        </div>
            <!--main page content-->
             <body>
                <body style="background-color: #962c3a;text-align:center">
                </body>
                <div class="container">
                <br>
                <br>
                <br>
                <br>
                <br>
                <h1>PASSWORD SUCCESSFULLY CHANGED</h1>
                <p>You will now be redirected</p>
             
                </div>

      


                </div>

            </div>
        </div>
        <span class="pix">
         </span>


    
        </footer>

    </div>
</body>
</html>