function OSM() { /* open the navigation bar pannel */
    document.getElementById("side-menu").style.width = "200px";
    document.getElementById("main").style.marginLeft = "200px";
}

function CSM() { /* close the navigation bar pannel */
    document.getElementById("side-menu").style.width = "0px";
    document.getElementById("main").style.marginLeft = "0px";
}
